// ELS-DefIntSimple/CompVal.java
 
public class CompVal implements MyCompar {
    @Override
    public boolean lt(int lhs, int rhs) {
        return lhs < rhs;
    }
}
