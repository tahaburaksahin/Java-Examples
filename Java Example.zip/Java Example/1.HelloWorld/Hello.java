// AAC-HelloWorld/Hello.java
 
/*
 *  Program Hello
 *  It prints "Hello, World"
 */

public class Hello { /* Entry class must be public
                        File name = class name!   */
    public static void main(String[] args) {
        System.out.println("Hello, World");
    }
    // signature of 'main' always like this
}
