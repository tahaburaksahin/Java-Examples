// FUI-AnnoProc/CarSkel.java
 
package myapplication;

@myprocessor.MyBean
public class CarSkel {
    String  make;
    double speed;
}
