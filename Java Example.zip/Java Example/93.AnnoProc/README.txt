Files MyBean.java and MyProcessor.java
should go to subdirectory 'myprocessor';
files CarSkel.java, PersonSkel.java and
AnnoTest.java should go to subdirectory
'myapplication'.
Then run what's in 'go.script'.
