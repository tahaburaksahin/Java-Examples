// FUI-AnnoProc/PersonSkel.java
 
package myapplication;

@myprocessor.MyBean
public class PersonSkel {
    Car     car;
    String name;
    int    year;
}
