// LTF-Calendars/Cals.java
 
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
import javax.swing.JOptionPane;

public class Cals {
    public static void main(String[] args) {

        Calendar cal = Calendar.getInstance(
            TimeZone.getTimeZone("US/Central"),
            Locale.US
        );

          //    yyyy  m  d   Elvis born in Memphis
        cal.set(1935, 0, 8);
          //          |
          //      January!!!

        StringBuilder sb = new StringBuilder("<html>");
        sb.append(cal.getTime().toString());

        sb.append("<br />Year             : " +
                cal.get(Calendar.YEAR));
          // Months numbered from 0!!!
        sb.append("<br />Month            : " +
                cal.get(Calendar.MONTH));
        sb.append("<br />        in French: " +
                cal.getDisplayName(
                    Calendar.MONTH,Calendar.LONG,
                    Locale.FRENCH));
        sb.append("<br />        in Polish: " +
                cal.getDisplayName(
                    Calendar.MONTH,Calendar.LONG,
                    new Locale("pl")));
        sb.append("<br />Day              : " +
                cal.get(Calendar.DAY_OF_MONTH));
        // Sunday is 1, Saturday is 7
        sb.append("<br />Day of week      : " +
                cal.get(Calendar.DAY_OF_WEEK));
        sb.append("<br />        in French: " +
                cal.getDisplayName(
                    Calendar.DAY_OF_WEEK,Calendar.LONG,
                    Locale.FRENCH));

        long now  = System.currentTimeMillis();
        int  diff = (int)((now-cal.getTimeInMillis())
                                        /3600000./24);
        sb.append("<br />"+diff+ " days have passed");

        JOptionPane.showMessageDialog(null,sb.toString(),
            "ELVIS",JOptionPane.INFORMATION_MESSAGE);
        System.exit(0);
    }
}
