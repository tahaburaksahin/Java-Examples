// CYE-SimpEnum/Suit.java
 
public enum Suit {CLUBS,DIAMONDS,HEARTS,SPADES};
